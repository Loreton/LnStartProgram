#!/usr/bin/python3.5
#
# Scope:  Programma per ...........
# updated by Loreto: 24-10-2017 12.48.27
# -----------------------------------------------
class LnClass(): pass

# from . LaunchProgram                import LaunchProgram
from . CalculateMainDirs                import CalculateMainDirs


from . ParseInput                import ParseInput
from . SetTotalCommander                import SetTotalCommander
from . SetExecutor                import SetExecutor


# from . OsEnvVar                import setOsEnv
# from . OsEnvVar                import SetEnvPaths
# from . OsEnvVar                import SetEnvVars
